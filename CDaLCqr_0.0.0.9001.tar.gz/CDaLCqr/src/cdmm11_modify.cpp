// [[Rcpp::depends(RcppEigen)]]
//#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <RcppEigen.h>
#include <math.h>
#include <limits>
using namespace Rcpp;
//using namespace arma;
using namespace Eigen;

inline double photk(double x, double tau, double kk) {
  if (-(1 - tau) * kk > x) return tau - 1;
  if (x <= tau * kk) return x / kk;
  return tau;
}

inline double photc(double x, double tau, double c) {
  if (x < -c) return tau - 1;
  if (x < 0) return (1 - tau) / c;
  if (x < c) return tau / c;
  return tau;
}

inline double SS(double z, double u) {
  return std::max(0.0, fabs(z) - u) * (z > 0 ? 1 : (z < 0 ? -1 : 0));
}

// inline double mcp(double z1, double z2, double lambda) {
//   double f;
//   if(fabs(z1)<=1.2*lambda){
//     f=SS(z1,lambda)/(z2-1/1.2);
//   }else{
//     f=z1/z2;
//   }
//   return f;
// }

inline double mcp(double z1, double z2, double lambda, double Weight, double a) {
  double f;
  if(fabs(z1)<=a*lambda*z2){
    f=SS(z1,lambda)/(z2-1/a);
  }else{
    f=z1/z2;
  }
  return f;
}

inline double scad(double z1, double z2, double lambda, double Weight, double a) {
  double f;
  if(fabs(z1)<=lambda*(1+z2)){
    f=SS(z1,lambda)/z2;
  }else if(fabs(z1)<=a*z2*lambda){
    f=SS(z1,a*lambda/(a-1))/(z2-1/(a-1));
  }else{
    f=z1/z2;
  }
  return f;
}





// [[Rcpp::export]]
SEXP cdmm(Eigen::MatrixXd A, Eigen::MatrixXd B, Eigen::MatrixXd X, Eigen::MatrixXd Y, Eigen::MatrixXd Z,
          Eigen::MatrixXd Weight, double del, int n, int sumt, int p, int r, double miu, double lambda,
          double kk, double c, double tau, int cho, double eps, int maxit, std::string penalty,double a) {

  double gam = 0.0, gam1 = -1.0;
  int dai = 0, k;
  double alpha_change = std::numeric_limits<double>::infinity();
  double beta_change = std::numeric_limits<double>::infinity();
  double constraint_residual = std::numeric_limits<double>::infinity();
  bool converged = false;
  Eigen::MatrixXd sum1(r, 1), sum2(r, 1), sum3(p, 1), sum4(p, 1), sum5(p, 1), zeta1(p, 1), zeta2(p, 1);
  Eigen::MatrixXd R;

  std::function<double(double, double, double, double, double)> BFunction;  
  if (penalty == "CONVEX") {
      // convex
      BFunction = [](double zeta1, double zeta2, double lambda, double weight, double a) {
          return SS(zeta1, lambda * weight) / zeta2;
      };
  } else if (penalty == "MCP") {
      // non-convex
      BFunction = [](double zeta1, double zeta2, double lambda, double weight, double a) {
          return mcp(zeta1, zeta2, lambda,weight,a);
      };
  } else {
      BFunction = [](double zeta1, double zeta2, double lambda, double weight, double a) {
          return scad(zeta1, zeta2, lambda,weight,a);
  };
  }
  for (k = 0; k < maxit; ++k) {
    const Eigen::MatrixXd A_previous = A;
    const Eigen::MatrixXd B_previous = B;
    R = Y - X * A - Z * B;

    if (cho == 1) {
      for (int j = 0; j < r; ++j) {
        sum1.setZero();
        sum2.setZero();
        for (int i = 0; i < sumt; ++i) {
          double res_val = photk(R(i, 0), tau, kk);
          sum1(j, 0) += res_val * X(i, j);
          sum2(j, 0) += X(i, j) * X(i, j);
        }
        double delta_a = sum1(j, 0) / (2 / del * sum2(j, 0));
        A(j, 0) += delta_a;
        for (int i = 0; i < sumt; ++i) R(i, 0) -= delta_a * X(i, j);   // refresh R
      }

      for (int q = 0; q < p; ++q) {
        // Only coordinate q is read before being overwritten below. Resetting
        // whole p-vectors here is unnecessary and dominates small-N sweeps.
        sum3(q, 0) = 0.0;
        sum4(q, 0) = 0.0;
        sum5(q, 0) = 0.0;
        for (int m = 0; m < sumt; ++m) {
          sum3(q, 0) += Z(m, q) * Z(m, q) * B(q, 0);
          sum4(q, 0) += photk(R(m, 0), tau, kk) * Z(m, q);
          sum5(q, 0) += Z(m, q) * Z(m, q);
        }
        zeta1(q, 0) = 2 / (del * n) * sum3(q, 0) + sum4(q, 0) / n - miu * (B.sum() - B(q, 0)) - gam;
        zeta2(q, 0) = 2 / (del * n) * sum5(q, 0) + miu;
        double old_Bq = B(q, 0);
        B(q, 0) = BFunction(zeta1(q, 0), zeta2(q, 0), lambda, Weight(q,0),a);
        double delta_b = B(q, 0) - old_Bq;
        for (int m = 0; m < sumt; ++m) R(m, 0) -= delta_b * Z(m, q);   // refresh R
      }

    } else {
      for (int j = 0; j < r; ++j) {
        sum1.setZero();
        sum2.setZero();
        for (int i = 0; i < sumt; ++i) {
          double res_val = photc(R(i, 0), tau, c);
          sum1(j, 0) += res_val * X(i, j);
          sum2(j, 0) += X(i, j) * X(i, j);
        }
        double delta_a2 = sum1(j, 0) / (2 / del * sum2(j, 0));
        A(j, 0) += delta_a2;
        for (int i = 0; i < sumt; ++i) R(i, 0) -= delta_a2 * X(i, j);   // refresh R
      }

      for (int q = 0; q < p; ++q) {
        // Only coordinate q is read before being overwritten below. Resetting
        // whole p-vectors here is unnecessary and dominates small-N sweeps.
        sum3(q, 0) = 0.0;
        sum4(q, 0) = 0.0;
        sum5(q, 0) = 0.0;
        for (int m = 0; m < sumt; ++m) {
          sum3(q, 0) += Z(m, q) * Z(m, q) * B(q, 0);
          sum4(q, 0) += photc(R(m, 0), tau, c) * Z(m, q);
          sum5(q, 0) += Z(m, q) * Z(m, q);
        }
        zeta1(q, 0) = 2 / (del * n) * sum3(q, 0) + sum4(q, 0) / n - miu * (B.sum() - B(q, 0)) - gam;
        zeta2(q, 0) = 2 / (del * n) * sum5(q, 0) + miu;
        double old_Bq2 = B(q, 0);
        B(q, 0) = BFunction(zeta1(q, 0),zeta2(q, 0), lambda, Weight(q,0),a);
        double delta_b2 = B(q, 0) - old_Bq2;
        for (int m = 0; m < sumt; ++m) R(m, 0) -= delta_b2 * Z(m, q);   // refresh R
      }
    }

    alpha_change = (A - A_previous).cwiseAbs().maxCoeff();
    beta_change = (B - B_previous).cwiseAbs().maxCoeff();
    constraint_residual = fabs(B.sum());
    gam1 = gam;
    gam += miu * B.sum();
    ++dai;
    if (std::max(alpha_change, std::max(beta_change, constraint_residual)) < eps) {
      converged = true;
      break;
    }
  }

  return Rcpp::wrap(List::create(
    Named("alpha") = A, Named("beta") = B, Named("gamma") = gam, Named("g") = gam1,
    Named("iterations") = dai, Named("alpha_change") = alpha_change,
    Named("beta_change") = beta_change, Named("constraint_residual") = constraint_residual,
    Named("converged") = converged));
}


/*** R

*/
