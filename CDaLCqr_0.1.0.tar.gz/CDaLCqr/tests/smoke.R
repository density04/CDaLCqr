## Minimal package smoke test (run by R CMD check and manually).
library(CDaLCqr)
set.seed(2026)
n <- 20; p <- 30; r <- 1; N <- 2 * n
X <- matrix(rnorm(N * r), N, r)
Z <- matrix(rnorm(N * p), N, p)
beta <- c(3, 2, 1.5, rep(0, p - 3))
Y <- drop(X %*% 1 + Z %*% beta + rnorm(N, sd = 0.5))
lam <- exp(seq(log(0.3), log(1e-4), length.out = 20))
fit <- CDaLCqr(x = cbind(X, Z), y = Y, r = r, p = p, n = n, tau = 0.5,
               lambda = lam, kk = 0.1, mu = 10, wgt_scale = 1,
               penalty = "CONVEX", eps = 1e-6, maxit = 1e5,
               select_ka = FALSE)
size <- sum(abs(drop(fit$beta_rq)) > 1e-6)
cat("lambda_best:", fit$lambda_best, "\n")
cat("selected nonzeros:", size, "(3 true signals)\n")
stopifnot(size >= 3, is.finite(fit$lambda_best))
cat("SMOKE TEST OK\n")
