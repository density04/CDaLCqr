// [[Rcpp::depends(RcppEigen)]]
//#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <RcppEigen.h>
#include <limits>
using namespace Rcpp;
//using namespace arma;
using namespace Eigen;
// [[Rcpp::export]]

SEXP GIC(Eigen::MatrixXd A, Eigen::MatrixXd B, Eigen::MatrixXd X, Eigen::MatrixXd Y, Eigen::MatrixXd Z,
         double tau, double kk, int n, int sumt, int p, int r, int len){
  double check_loss(double x, double tau);
  Eigen::MatrixXd R = Y-X*A-Z*B;
  Eigen::MatrixXd siglam;
  Eigen::MatrixXd sum1;
  Eigen::MatrixXd countS;
  Eigen::MatrixXd GIC;
  int i;
  int j;
  int k;
  double phi;
  siglam.setZero(len,1);
  sum1.setZero(len,1);
  countS.setZero(len,1);
  GIC.setZero(len,1);
  phi=(log(log(n))*log(p))/n;
  for(i=0;i<len;i++){
    for(j=0;j<sumt;j++){
      sum1(i,0)=sum1(i,0)+check_loss(R(j,i),tau);
    }
  }
  for(i=0;i<len;i++){
    siglam(i,0)=log(std::max(sum1(i,0)/n, std::numeric_limits<double>::min()));
  }
  for(i=0;i<len;i++){
    for(j=0;j<p;j++){
      if(fabs(B(j,i))>=0.00001)
        countS(i,0)=countS(i,0)+1;
      else countS(i,0)=countS(i,0);
    }
  }
  for(i=0;i<len;i++){
    GIC(i,0)=GIC(i,0)+siglam(i,0)+(countS(i,0)-1)*phi;
  }
  return Rcpp::wrap(GIC);
}

// Ordinary (unsmoothed) quantile check loss.  This is used only
// for GIC evaluation; the fitting algorithm still uses its smooth loss.
double check_loss(double x, double tau)
{
  return x * (tau - (x < 0.0 ? 1.0 : 0.0));
}
