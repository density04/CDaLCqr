// [[Rcpp::depends(RcppEigen)]]
//#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <RcppEigen.h>
#include <math.h>
#include <limits>
using namespace Rcpp;
//using namespace arma;
using namespace Eigen;

inline double photk(double x, double tau, double kk) {
  if (-(1 - tau) * kk > x) return tau - 1;
  if (x <= tau * kk) return x / kk;
  return tau;
}

inline double photc(double x, double tau, double c) {
  if (x < -c) return tau - 1;
  if (x < 0) return (1 - tau) / c;
  if (x < c) return tau / c;
  return tau;
}

inline double SS(double z, double u) {
  return std::max(0.0, fabs(z) - u) * (z > 0 ? 1 : (z < 0 ? -1 : 0));
}

// inline double mcp(double z1, double z2, double lambda) {
//   double f;
//   if(fabs(z1)<=1.2*lambda){
//     f=SS(z1,lambda)/(z2-1/1.2);
//   }else{
//     f=z1/z2;
//   }
//   return f;
// }

inline double mcp(double z1, double z2, double lambda, double Weight, double a) {
  double f;
  if(fabs(z1)<=a*lambda*z2){
    f=SS(z1,lambda)/(z2-1/a);
  }else{
    f=z1/z2;
  }
  return f;
}

inline double scad(double z1, double z2, double lambda, double Weight, double a) {
  double f;
  if(fabs(z1)<=lambda*(1+z2)){
    f=SS(z1,lambda)/z2;
  }else if(fabs(z1)<=a*z2*lambda){
    f=SS(z1,a*lambda/(a-1))/(z2-1/(a-1));
  }else{
    f=z1/z2;
  }
  return f;
}





// [[Rcpp::export]]
SEXP cdmm(Eigen::MatrixXd A, Eigen::MatrixXd B, Eigen::MatrixXd X, Eigen::MatrixXd Y, Eigen::MatrixXd Z,
          Eigen::MatrixXd Weight, double del, int n, int sumt, int p, int r, double miu, double lambda,
          double kk, double c, double tau, int cho, double eps, int maxit, std::string penalty,double a) {

  double gam = 0.0, gam1 = -1.0;
  int dai = 0, k;
  double alpha_change = std::numeric_limits<double>::infinity();
  double beta_change = std::numeric_limits<double>::infinity();
  double constraint_residual = std::numeric_limits<double>::infinity();
  bool converged = false;
  Eigen::MatrixXd sum1(r, 1), sum2(r, 1), sum3(p, 1), sum4(p, 1), sum5(p, 1), zeta1(p, 1), zeta2(p, 1);
  Eigen::MatrixXd R;

  std::function<double(double, double, double, double, double)> BFunction;  
  if (penalty == "CONVEX") {
      // convex
      BFunction = [](double zeta1, double zeta2, double lambda, double weight, double a) {
          return SS(zeta1, lambda * weight) / zeta2;
      };
  } else if (penalty == "MCP") {
      // non-convex
      BFunction = [](double zeta1, double zeta2, double lambda, double weight, double a) {
          return mcp(zeta1, zeta2, lambda,weight,a);
      };
  } else {
      BFunction = [](double zeta1, double zeta2, double lambda, double weight, double a) {
          return scad(zeta1, zeta2, lambda,weight,a);
  };
  }
  for (k = 0; k < maxit; ++k) {
    const Eigen::MatrixXd A_previous = A;
    const Eigen::MatrixXd B_previous = B;
    R = Y - X * A - Z * B;

    if (cho == 1) {
      for (int j = 0; j < r; ++j) {
        sum1.setZero();
        sum2.setZero();
        for (int i = 0; i < sumt; ++i) {
          double res_val = photk(R(i, 0), tau, kk);
          sum1(j, 0) += res_val * X(i, j);
          sum2(j, 0) += X(i, j) * X(i, j);
        }
        double delta_a = sum1(j, 0) / (2 / del * sum2(j, 0));
        A(j, 0) += delta_a;
        for (int i = 0; i < sumt; ++i) R(i, 0) -= delta_a * X(i, j);   // refresh R
      }

      for (int q = 0; q < p; ++q) {
        // Only coordinate q is read before being overwritten below. Resetting
        // whole p-vectors here is unnecessary and dominates small-N sweeps.
        sum3(q, 0) = 0.0;
        sum4(q, 0) = 0.0;
        sum5(q, 0) = 0.0;
        for (int m = 0; m < sumt; ++m) {
          sum3(q, 0) += Z(m, q) * Z(m, q) * B(q, 0);
          sum4(q, 0) += photk(R(m, 0), tau, kk) * Z(m, q);
          sum5(q, 0) += Z(m, q) * Z(m, q);
        }
        zeta1(q, 0) = 2 / (del * n) * sum3(q, 0) + sum4(q, 0) / n - miu * (B.sum() - B(q, 0)) - gam;
        zeta2(q, 0) = 2 / (del * n) * sum5(q, 0) + miu;
        double old_Bq = B(q, 0);
        B(q, 0) = BFunction(zeta1(q, 0), zeta2(q, 0), lambda, Weight(q,0),a);
        double delta_b = B(q, 0) - old_Bq;
        for (int m = 0; m < sumt; ++m) R(m, 0) -= delta_b * Z(m, q);   // refresh R
      }

    } else {
      for (int j = 0; j < r; ++j) {
        sum1.setZero();
        sum2.setZero();
        for (int i = 0; i < sumt; ++i) {
          double res_val = photc(R(i, 0), tau, c);
          sum1(j, 0) += res_val * X(i, j);
          sum2(j, 0) += X(i, j) * X(i, j);
        }
        double delta_a2 = sum1(j, 0) / (2 / del * sum2(j, 0));
        A(j, 0) += delta_a2;
        for (int i = 0; i < sumt; ++i) R(i, 0) -= delta_a2 * X(i, j);   // refresh R
      }

      for (int q = 0; q < p; ++q) {
        // Only coordinate q is read before being overwritten below. Resetting
        // whole p-vectors here is unnecessary and dominates small-N sweeps.
        sum3(q, 0) = 0.0;
        sum4(q, 0) = 0.0;
        sum5(q, 0) = 0.0;
        for (int m = 0; m < sumt; ++m) {
          sum3(q, 0) += Z(m, q) * Z(m, q) * B(q, 0);
          sum4(q, 0) += photc(R(m, 0), tau, c) * Z(m, q);
          sum5(q, 0) += Z(m, q) * Z(m, q);
        }
        zeta1(q, 0) = 2 / (del * n) * sum3(q, 0) + sum4(q, 0) / n - miu * (B.sum() - B(q, 0)) - gam;
        zeta2(q, 0) = 2 / (del * n) * sum5(q, 0) + miu;
        double old_Bq2 = B(q, 0);
        B(q, 0) = BFunction(zeta1(q, 0),zeta2(q, 0), lambda, Weight(q,0),a);
        double delta_b2 = B(q, 0) - old_Bq2;
        for (int m = 0; m < sumt; ++m) R(m, 0) -= delta_b2 * Z(m, q);   // refresh R
      }
    }

    alpha_change = (A - A_previous).cwiseAbs().maxCoeff();
    beta_change = (B - B_previous).cwiseAbs().maxCoeff();
    constraint_residual = fabs(B.sum());
    gam1 = gam;
    gam += miu * B.sum();
    ++dai;
    if (std::max(alpha_change, std::max(beta_change, constraint_residual)) < eps) {
      converged = true;
      break;
    }
  }

  return Rcpp::wrap(List::create(
    Named("alpha") = A, Named("beta") = B, Named("gamma") = gam, Named("g") = gam1,
    Named("iterations") = dai, Named("alpha_change") = alpha_change,
    Named("beta_change") = beta_change, Named("constraint_residual") = constraint_residual,
    Named("converged") = converged));
}



// ============================================================================
// Coordinate-descent kernel.
//
// Solves the smoothed quantile regression problem for one value of lambda.
// After initialising the residuals and the running beta sum, each sweep
//
//   * updates every alpha coefficient from the closed-form derivative of the
//     smoothed check loss, photk(r) = clamp(r/kk, tau - 1, tau);
//   * updates every beta coefficient through the proximal operator of the
//     selected penalty (adaptive lasso, MCP or SCAD);
//   * applies the augmented-Lagrangian multiplier update and tracks the
//     largest absolute coefficient change for the convergence test.
//
// The column norms of X and Z are computed once per call, the residual is
// maintained incrementally between sweeps, and gam_init sets the initial
// value of the dual multiplier.  Convergence is declared when the largest
// coefficient change is below eps.
// ============================================================================

namespace cdmm_opt_detail {

// Soft-thresholding operator: SS(z, u) = max(0, |z| - u) * sign(z).
inline double ss_inline(double z, double u) {
  const double a = std::fabs(z) - u;
  const double pos = a > 0.0 ? a : 0.0;
  const double sgn = z > 0.0 ? 1.0 : (z < 0.0 ? -1.0 : 0.0);
  return pos * sgn;
}

// Proximal update for the selected penalty.  The adaptive lasso branch uses
// the weight, while the MCP and SCAD branches do not.
inline double penalty_update(int code, double z1, double z2, double lambda,
                             double weight, double a) {
  if (code == 0) {  // CONVEX / adaptive lasso
    return ss_inline(z1, lambda * weight) / z2;
  }
  if (code == 1) {  // MCP
    if (std::fabs(z1) <= a * lambda * z2) {
      return ss_inline(z1, lambda) / (z2 - 1.0 / a);
    }
    return z1 / z2;
  }
  // SCAD
  if (std::fabs(z1) <= lambda * (1.0 + z2)) {
    return ss_inline(z1, lambda) / z2;
  }
  if (std::fabs(z1) <= a * z2 * lambda) {
    return ss_inline(z1, a * lambda / (a - 1.0)) / (z2 - 1.0 / (a - 1.0));
  }
  return z1 / z2;
}

// photk for the whole residual at once: clamp(R/kk, tau-1, tau).
inline void fill_photk(const Eigen::VectorXd& R, double tau_m1, double tau,
                       double inv_kk, Eigen::VectorXd& ph) {
  ph = (R.array() * inv_kk).max(tau_m1).min(tau).matrix();
}

// dot(clamp(R/kk, tau-1, tau), v) computed in a single pass: the clamped
// residual vector is never materialised (saves one store + one load of length
// N per coordinate update; identical arithmetic to fill_photk + ph.dot(v)).
inline double clamped_dot_photk(const Eigen::VectorXd& R, double tau_m1,
                                double tau, double inv_kk,
                                const Eigen::Map<const Eigen::VectorXd>& v) {
  return (R.array() * inv_kk).max(tau_m1).min(tau).matrix().dot(v);
}

// photc for the whole residual at once (cho == 2 branch).
inline void fill_photc(const Eigen::VectorXd& R, double tau, double c,
                       Eigen::VectorXd& ph) {
  const double tau_m1 = tau - 1.0;
  const double neg = (1.0 - tau) / c;
  const double pos = tau / c;
  const double* r = R.data();
  double* p = ph.data();
  const Eigen::Index N = R.size();
  for (Eigen::Index i = 0; i < N; ++i) {
    const double x = r[i];
    p[i] = x < -c ? tau_m1 : (x < 0.0 ? neg : (x < c ? pos : tau));
  }
}

}  // namespace cdmm_opt_detail

// [[Rcpp::export]]
SEXP cdmm_opt(Eigen::MatrixXd A, Eigen::MatrixXd B, Eigen::MatrixXd X, Eigen::MatrixXd Y,
              Eigen::MatrixXd Z, Eigen::MatrixXd Weight, double del, int n, int sumt,
              int p, int r, double miu, double lambda, double kk, double c, double tau,
              int cho, double eps, int maxit, std::string penalty, double a,
              double gam_init, int refresh_every) {

  using namespace cdmm_opt_detail;

  double gam = gam_init;
  double gam1 = -1.0;
  int dai = 0;
  double alpha_change = std::numeric_limits<double>::infinity();
  double beta_change = std::numeric_limits<double>::infinity();
  double constraint_residual = std::numeric_limits<double>::infinity();
  bool converged = false;

  // Penalty code: 0 = CONVEX (adaptive lasso), 1 = MCP, 2 = SCAD (default),
  // with 0 = adaptive lasso, 1 = MCP and 2 = SCAD.
  int pcode = 0;
  if (penalty == "MCP") {
    pcode = 1;
  } else if (penalty != "CONVEX") {
    pcode = 2;
  }

  const Eigen::Index N = static_cast<Eigen::Index>(sumt);
  Eigen::VectorXd R(N), ph(N);
  Eigen::VectorXd Xsq(r), Zsq(p);

  // Column squared norms, computed once per call.
  for (int j = 0; j < r; ++j) {
    double s = 0.0;
    for (Eigen::Index i = 0; i < N; ++i) s += X(i, j) * X(i, j);
    Xsq(j) = s;
  }
  for (int q = 0; q < p; ++q) {
    double s = 0.0;
    for (Eigen::Index m = 0; m < N; ++m) s += Z(m, q) * Z(m, q);
    Zsq(q) = s;
  }

  const double two_over_del = 2.0 / del;
  const double two_over_deln = 2.0 / (del * static_cast<double>(n));
  const double inv_n = 1.0 / static_cast<double>(n);
  const double inv_kk = 1.0 / kk;
  const double tau_m1 = tau - 1.0;
  const bool use_photk = (cho == 1);

  // Initial residual; it is maintained incrementally from here on.
  R.noalias() = Y - X * A - Z * B;

  for (int k = 0; k < maxit; ++k) {
    if (k > 0 && refresh_every > 0 && (k % refresh_every) == 0) {
      // Periodic exact refresh to keep the incremental residual round-off-free.
      R.noalias() = Y - X * A - Z * B;
    }

    // ---- alpha sweep (r coordinates) --------------------------------------
    double max_da = 0.0;
    for (int j = 0; j < r; ++j) {
      const Eigen::Map<const Eigen::VectorXd> xj(X.col(j).data(), N);
      double sum1;
      if (use_photk) {
        sum1 = clamped_dot_photk(R, tau_m1, tau, inv_kk, xj);
      } else {
        fill_photc(R, tau, c, ph);
        sum1 = ph.dot(xj);
      }
      const double delta_a = sum1 / (two_over_del * Xsq(j));
      A(j, 0) += delta_a;
      R.noalias() -= delta_a * xj;
      const double ad = std::fabs(delta_a);
      if (ad > max_da) max_da = ad;
    }

    // ---- beta sweep (p coordinates) ---------------------------------------
    double bsum = B.sum();  // running sum of beta, updated in O(1) below
    double max_db = 0.0;
    for (int q = 0; q < p; ++q) {
      const double Bq = B(q, 0);
      const Eigen::Map<const Eigen::VectorXd> zq(Z.col(q).data(), N);
      double sum4;
      if (use_photk) {
        sum4 = clamped_dot_photk(R, tau_m1, tau, inv_kk, zq);
      } else {
        fill_photc(R, tau, c, ph);
        sum4 = ph.dot(zq);
      }
      const double zsq = Zsq(q);
      const double zeta1 = two_over_deln * (zsq * Bq) + sum4 * inv_n
                           - miu * (bsum - Bq) - gam;
      const double zeta2 = two_over_deln * zsq + miu;
      const double new_Bq = penalty_update(pcode, zeta1, zeta2, lambda,
                                           Weight(q, 0), a);
      B(q, 0) = new_Bq;
      const double delta_b = new_Bq - Bq;
      bsum += delta_b;
      R.noalias() -= delta_b * zq;
      const double bd = std::fabs(delta_b);
      if (bd > max_db) max_db = bd;
    }

    alpha_change = max_da;
    beta_change = max_db;
    constraint_residual = std::fabs(bsum);
    gam1 = gam;
    gam += miu * bsum;
    ++dai;
    if (std::max(alpha_change, std::max(beta_change, constraint_residual)) < eps) {
      converged = true;
      break;
    }
  }

  return Rcpp::wrap(List::create(
    Named("alpha") = A, Named("beta") = B, Named("gamma") = gam, Named("g") = gam1,
    Named("iterations") = dai, Named("alpha_change") = alpha_change,
    Named("beta_change") = beta_change, Named("constraint_residual") = constraint_residual,
    Named("converged") = converged));
}



// ============================================================================
// Screened coordinate-descent kernel.
//
// Same model and updates as cdmm_opt, with inactive-coordinate screening.
// After every full gradient scan the margin of each zero beta coefficient
// (the amount by which its subgradient condition is satisfied) is compared
// with an upper bound on how much its score can change before the next full
// scan, and the coefficient is skipped while the margin stays above the
// bound.  The bound accounts for drift in the residual, the multiplier and
// the running beta sum.  Beta coordinates are visited in ascending order,
// and the residual is rebuilt at every sweep when refresh_every = 1.  The
// rule is exact: skipped coefficients remain KKT-satisfying at every check,
// so the returned solution is the same as that of cdmm_opt.
// ============================================================================

// [[Rcpp::export]]
SEXP cdmm_opt_as(Eigen::MatrixXd A, Eigen::MatrixXd B, Eigen::MatrixXd X, Eigen::MatrixXd Y,
              Eigen::MatrixXd Z, Eigen::MatrixXd Weight, double del, int n, int sumt,
              int p, int r, double miu, double lambda, double kk, double c, double tau,
              int cho, double eps, int maxit, std::string penalty, double a,
              double gam_init, int refresh_every, int kkt_every) {

  using namespace cdmm_opt_detail;

  double gam = gam_init;
  double gam1 = -1.0;
  int dai = 0;
  double alpha_change = std::numeric_limits<double>::infinity();
  double beta_change = std::numeric_limits<double>::infinity();
  double constraint_residual = std::numeric_limits<double>::infinity();
  bool converged = false;

  // Penalty code: 0 = CONVEX (adaptive lasso), 1 = MCP, 2 = SCAD (default),
  // with 0 = adaptive lasso, 1 = MCP and 2 = SCAD.
  int pcode = 0;
  if (penalty == "MCP") {
    pcode = 1;
  } else if (penalty != "CONVEX") {
    pcode = 2;
  }

  const Eigen::Index N = static_cast<Eigen::Index>(sumt);
  Eigen::VectorXd R(N), ph(N);
  Eigen::VectorXd Xsq(r), Zsq(p);

  // Column squared norms, computed once per call.
  for (int j = 0; j < r; ++j) {
    double s = 0.0;
    for (Eigen::Index i = 0; i < N; ++i) s += X(i, j) * X(i, j);
    Xsq(j) = s;
  }
  for (int q = 0; q < p; ++q) {
    double s = 0.0;
    for (Eigen::Index m = 0; m < N; ++m) s += Z(m, q) * Z(m, q);
    Zsq(q) = s;
  }

  const double two_over_del = 2.0 / del;
  const double two_over_deln = 2.0 / (del * static_cast<double>(n));
  const double inv_n = 1.0 / static_cast<double>(n);
  const double inv_kk = 1.0 / kk;
  const double tau_m1 = tau - 1.0;
  const bool use_photk = (cho == 1);

  // Initial residual; it is maintained incrementally from here on.
  R.noalias() = Y - X * A - Z * B;

  // Screen only the smoothed photk branch, where the score is 1/kk-Lipschitz.
  const int scan_period = (use_photk && kk > 0.0 && kkt_every >= 2)
    ? kkt_every : 0;
  Eigen::VectorXd zero_margin = Eigen::VectorXd::Zero(p);
  Eigen::VectorXd residual_snapshot;
  double beta_sum_snapshot = 0.0, gamma_snapshot = 0.0;
  bool snapshot_ready = false;
  double skipped_zero_updates = 0.0, checked_beta_updates = 0.0;
  int full_gradient_scans = 0;

  for (int k = 0; k < maxit; ++k) {
    const bool full_scan = scan_period > 0 &&
      (!snapshot_ready || k % scan_period == 0);
    if (k > 0 && refresh_every > 0 && (k % refresh_every) == 0) {
      // Periodic exact refresh to keep the incremental residual round-off-free.
      R.noalias() = Y - X * A - Z * B;
    }

    // ---- alpha sweep (r coordinates) --------------------------------------
    double max_da = 0.0;
    for (int j = 0; j < r; ++j) {
      const Eigen::Map<const Eigen::VectorXd> xj(X.col(j).data(), N);
      double sum1;
      if (use_photk) {
        sum1 = clamped_dot_photk(R, tau_m1, tau, inv_kk, xj);
      } else {
        fill_photc(R, tau, c, ph);
        sum1 = ph.dot(xj);
      }
      const double delta_a = sum1 / (two_over_del * Xsq(j));
      A(j, 0) += delta_a;
      R.noalias() -= delta_a * xj;
      const double ad = std::fabs(delta_a);
      if (ad > max_da) max_da = ad;
    }

    // ---- beta sweep (p coordinates) ---------------------------------------
    double bsum = B.sum();  // running sum of beta, updated in O(1) below
    double max_db = 0.0;
    // Current norm after the alpha sweep; within the beta sweep, use a
    // triangle bound for all subsequent coordinate changes.
    double residual_drift = (!full_scan && snapshot_ready)
      ? (R - residual_snapshot).norm() : 0.0;
    for (int q = 0; q < p; ++q) {
      if (!full_scan && snapshot_ready && B(q, 0) == 0.0) {
        const double bound = std::sqrt(Zsq(q)) * residual_drift * inv_n * inv_kk
          + std::fabs(miu) * std::fabs(bsum - beta_sum_snapshot)
          + std::fabs(gam - gamma_snapshot);
        if (zero_margin(q) > bound + 1e-12) {
          ++skipped_zero_updates;
          continue;
        }
      }
      ++checked_beta_updates;
      const double Bq = B(q, 0);
      const Eigen::Map<const Eigen::VectorXd> zq(Z.col(q).data(), N);
      double sum4;
      if (use_photk) {
        sum4 = clamped_dot_photk(R, tau_m1, tau, inv_kk, zq);
      } else {
        fill_photc(R, tau, c, ph);
        sum4 = ph.dot(zq);
      }
      const double zsq = Zsq(q);
      const double zeta1 = two_over_deln * (zsq * Bq) + sum4 * inv_n
                           - miu * (bsum - Bq) - gam;
      const double zeta2 = two_over_deln * zsq + miu;
      const double new_Bq = penalty_update(pcode, zeta1, zeta2, lambda,
                                           Weight(q, 0), a);
      B(q, 0) = new_Bq;
      const double delta_b = new_Bq - Bq;
      bsum += delta_b;
      if (!full_scan && snapshot_ready)
        residual_drift += std::fabs(delta_b) * std::sqrt(Zsq(q));
      R.noalias() -= delta_b * zq;
      const double bd = std::fabs(delta_b);
      if (bd > max_db) max_db = bd;
    }

    alpha_change = max_da;
    beta_change = max_db;
    constraint_residual = std::fabs(bsum);
    gam1 = gam;
    gam += miu * bsum;
    ++dai;
    if (full_scan) {
      // One common completed-iterate snapshot for all zero coordinates.
      // The strict margin and Lipschitz drift bound certify that a skipped
      // coordinate would have returned zero at its actual update position.
      for (int q = 0; q < p; ++q) {
        if (B(q, 0) != 0.0) {
          zero_margin(q) = 0.0;
          continue;
        }
        const Eigen::Map<const Eigen::VectorXd> zq(Z.col(q).data(), N);
        const double zeta2 = two_over_deln * Zsq(q) + miu;
        if ((pcode == 1 && a * zeta2 <= 1.0) ||
            (pcode == 2 && zeta2 <= 0.0)) {
          zero_margin(q) = 0.0;
          continue;
        }
        const double score = clamped_dot_photk(R, tau_m1, tau, inv_kk, zq)
          * inv_n - miu * bsum - gam;
        const double threshold = pcode == 0 ? lambda * Weight(q, 0) : lambda;
        zero_margin(q) = threshold - std::fabs(score);
      }
      residual_snapshot = R;
      beta_sum_snapshot = bsum;
      gamma_snapshot = gam;
      snapshot_ready = true;
      ++full_gradient_scans;
    }
    if (std::max(alpha_change, std::max(beta_change, constraint_residual)) < eps) {
      converged = true;
      break;
    }
  }

  return Rcpp::wrap(List::create(
    Named("alpha") = A, Named("beta") = B, Named("gamma") = gam, Named("g") = gam1,
    Named("iterations") = dai, Named("alpha_change") = alpha_change,
    Named("beta_change") = beta_change, Named("constraint_residual") = constraint_residual,
    Named("converged") = converged,
    Named("skipped_zero_updates") = skipped_zero_updates,
    Named("checked_beta_updates") = checked_beta_updates,
    Named("full_gradient_scans") = full_gradient_scans));
}


/*** R

*/
