# CDaLCqr 0.1.0

## New features

* New C++ coordinate-descent kernels (`cdmm_opt`, `cdmm_opt_as`). The
  residual and the running beta sum are maintained incrementally, the column
  norms are computed once per call, and the penalty updates are inlined.
* Inactive-coordinate screening. After every full gradient scan the zero
  coefficients are skipped while an upper bound on the drift of their score
  stays below the KKT margin. The rule is exact and the solution is the same
  as that of the plain kernel.
* `CDaLCqr()` now returns the whole coefficient path
  (`alpha_path`, `beta_path`), the GIC sequence and the diagnostics of the
  selected fit (`iterations`, `converged`, `skipped_zero_updates`,
  `checked_beta_updates`, `full_gradient_scans`).
* The Belloni--Chernozhukov pilot lambda is vectorized, which removes the
  O(N^2 p) R loop from the initialization.
* Two opt-in environment switches used by the simulation study:
  `CDA_PILOT_SCALE` and `CDA_WEIGHT_MODE` (see `R/ini1fk.R`).

## API changes

* The `ini` argument of `CDaLCqr()` is removed. The second initialization
  strategy is no longer part of the package; the Belloni--Chernozhukov pilot
  fit is the only initialization.
* The `eps1`, `maxit1`, `use_cpp` and `active_scan_period` arguments are
  removed. Screening is always active, with a full gradient scan every 25
  iterations.
* `ini2fk()` is removed.
* `CDaLCqr()` gains `penalty = "SCAD"` support and the `select_ka`,
  `kk_grid` and `a_grid` arguments for a GIC search over the penalty shape.

# CDaLCqr 0.0.0.9001

* First version: coordinate descent for longitudinal quantile regression with
  compositional covariates, adaptive lasso penalty, two initialization
  strategies (`ini = 1` and `ini = 2`).
