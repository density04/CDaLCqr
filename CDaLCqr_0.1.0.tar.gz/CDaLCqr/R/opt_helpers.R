## Internal performance helpers for CDaLCqr (not exported).

## Exact vectorized equivalent of
##   Rlambda <- rep(0, N); tmpZ <- sweep(Z.p, 2, 1/HatSigma, "*")
##   for (i in 1:N) { U <- runif(N); tmpLamb[k] <- max(abs((tau[k]-(U<=tau[k]))
##                    %*% tmpZ / sqrt(tau[k]*(1-tau[k])))); Rlambda[i] <- max(tmpLamb) }
## The runif() stream is consumed in the same order (column-major blocks of
## replicate draws), so Rlambda matches the original loop up to floating-point
## summation order inside crossprod().
.bc_rlambda <- function(Z.p, HatSigma, tau, block = 500L) {
  N <- nrow(Z.p)
  tmpZ <- sweep(Z.p, 2L, 1 / HatSigma, "*")
  uvals <- as.numeric(tau)
  Rmax <- numeric(N)
  block <- max(1L, as.integer(block))
  start <- 1L
  while (start <= N) {
    nb <- min(block, N - start + 1L)
    ## column j of Ub is the U vector of replication start+j-1, in the same
    ## order in which the original loop drew it
    Ub <- matrix(stats::runif(N * nb), nrow = N)
    idx <- start:(start + nb - 1L)
    for (u in uvals) {
      Vb <- u - (Ub <= u)
      G <- crossprod(Vb, tmpZ)                      # nb x p, BLAS
      cand <- apply(abs(G), 1L, max) / sqrt(u * (1 - u))
      Rmax[idx] <- pmax(Rmax[idx], cand)
    }
    start <- start + nb
  }
  Rmax
}

## Solve the tuning grid through the coordinate-descent kernel.  Every lambda
## starts from the same initial value (a0, b0) with multiplier gamma = 0 and the
## working residual is rebuilt at every outer iteration (refresh_every = 1).
## Inactive-coordinate screening is always active, with a full gradient scan
## every 25 outer iterations.
.cda_path <- function(a0, b0, X.p, Y, Z.p, Weight, del, n, N, p, r, mu,
                      lambda1, kk, tau, eps, maxit, penalty, a) {
  nlam <- length(lambda1)
  alp_0 <- matrix(NA_real_, nlam, r)
  bet_0 <- matrix(NA_real_, nlam, p)
  iterations <- integer(nlam)
  alpha_change <- rep(NA_real_, nlam)
  beta_change <- rep(NA_real_, nlam)
  constraint_residual <- rep(NA_real_, nlam)
  converged <- logical(nlam)
  skipped_zero_updates <- numeric(nlam)
  checked_beta_updates <- numeric(nlam)
  full_gradient_scans <- integer(nlam)
  A <- as.matrix(a0)
  B <- as.matrix(b0)
  for (i in seq_len(nlam)) {
    model <- .Call("_CDaLCqr_cdmm_opt_as", A, B, X.p, Y, Z.p, Weight,
                   del, n, N, p, r, mu, lambda1[i], kk, 0, tau, 1L,
                   eps, maxit, penalty, a, 0, 1L, 25L)
    skipped_zero_updates[i] <- model$skipped_zero_updates
    checked_beta_updates[i] <- model$checked_beta_updates
    full_gradient_scans[i] <- model$full_gradient_scans
    alp_0[i, ] <- model[[1]]
    bet_0[i, ] <- model[[2]]
    iterations[i] <- model$iterations
    alpha_change[i] <- model$alpha_change
    beta_change[i] <- model$beta_change
    constraint_residual[i] <- model$constraint_residual
    converged[i] <- model$converged
  }
  list(alp_0 = alp_0, bet_0 = bet_0, iterations = iterations,
       alpha_change = alpha_change, beta_change = beta_change,
       constraint_residual = constraint_residual, converged = converged,
       skipped_zero_updates = skipped_zero_updates,
       checked_beta_updates = checked_beta_updates,
       full_gradient_scans = full_gradient_scans)
}
