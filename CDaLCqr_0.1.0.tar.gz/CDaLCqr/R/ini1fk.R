#' Belloni--Chernozhukov pilot fit
#'
#' Computes the uniformly consistent pilot estimate that the locally adaptive
#' weights are built from.
#'
#' @param x data for r covariates and p compositional covariates
#' @param y data for response outcomes
#' @param r dimension of covariates
#' @param p dimension of compositional covariates
#' @param n number of subjects
#' @param N total number of observations
#' @param tau quantile
#' @param lambda1 sequence of tuning parameter lambda('s)
#' @param nlam the length of lambda1
#' @param eps parameter for the determination of iteration convergence in the CDA, defaulted as 1e-06
#' @param maxit maximum number of iterations in the CDA, defaulted as 1e+04
#' @param mu penalty parameter in the CDA, defaulted as 1
#' @param kk parameter for the smooth approximate loss function in the CDA, defaulted as 0.01
#' @param wgt_scale used to scale the whole weights, in conjunction with lambda, and defaulted as 1
#' @param penalty penalty type: "Adaptive Lasso", "MCP" or "SCAD"
#' @param a shape parameter of the MCP or SCAD penalty
#'
#' @export
#'
ini1fk <- function(x, y, r, p, n, N, tau, lambda1, nlam, eps, maxit, mu, kk, wgt_scale, penalty, a) {
penalty <- normalize_penalty(penalty)
#################################################################################
#data setup
#y <- as.numeric(y)
if (kk < 0)
  stop("k must be non-negative")
kk <- as.double(kk)
if (tau < 0 | tau > 1)
  stop("taux must be between 0 and 1")
tau <- as.double(tau)
r <- as.integer(r)
p <- as.integer(p)
n <- as.integer(n)
N <- as.integer(N)
nlam <- as.integer(nlam)
wgt_scale <- as.double(wgt_scale)
eps<-as.double(eps)
maxit <- as.integer(maxit)
mu <- as.double(mu)
#################################################################################
XZ<-as.matrix(x)
storage.mode(XZ) <- "double"
X.p<-as.matrix(XZ[,1:r])
Z.p<-as.matrix(XZ[,(r+1):(r+p)])
Y<-as.matrix(as.double(y))
lambda1<-as.vector(as.double(lambda1))
zero<-matrix(rep(0,2*p*r),ncol=r,byrow=TRUE)
d1<-diag(1,nrow=p)
d2<- -d1
HatSigma<-sqrt(apply(Z.p^2, 2, mean))
wgt<-sqrt(tau*( 1 -tau) )*HatSigma
d1_1<-d1%*%diag(wgt)
d2_1<-d2%*%diag(wgt)
d<-rbind(d1_1,d2_1)
coupled<-cbind(zero,d)
######## Find Lambda for BC's method ########
## vectorized version of the original O(N^2 p) R loop; identical runif stream
Rlambda<- .bc_rlambda(Z.p, HatSigma, tau)
rlambda<-stats::quantile(Rlambda,0.1)/2
ps<-suppressWarnings(as.numeric(Sys.getenv("CDA_PILOT_SCALE","1"))); if(is.finite(ps)) rlambda<-rlambda*ps
#############################################
R1<-matrix(c(rep(0,r),rep(1,p)),ncol=r+p)
R2<-matrix(c(rep(0,r),rep(-1,p)),ncol=r+p)
R<-rbind(R1,R2)
rr<-matrix(c(0,0),ncol=1)
Y_0<-rbind(Y,matrix(rep(0,2*p),ncol=1))
uce<-quantreg::rq.fit.fnc(x=rbind(XZ,rlambda*coupled), y=Y_0, R=R,r=rr,tau=tau, beta=0.98, eps=1e-04)$coef
pb<-uce[(r+1):(r+p)]
if(identical(Sys.getenv("CDA_WEIGHT_MODE"),"alpqr")){pb[abs(pb)<1e-6]<-0; Weight<-1/abs(pb); Weight[!is.finite(Weight)]<-1e10}else{Weight<-1/(abs(pb)+1e-6)}
Weight<-Weight/wgt_scale  ##
Weight<-matrix(Weight,ncol=1)
a1<-matrix(uce[1:r],ncol=1)
b1<-matrix(uce[(r+1):(r+p)],ncol=1)
# call C++ core
del<-kk
.path <- .cda_path(a1, b1, X.p, Y, Z.p, Weight, del, n, N, p, r, mu,
                   lambda1, kk, tau, eps, maxit, penalty, a)
alp_0 <- .path$alp_0
bet_0 <- .path$bet_0
iterations <- .path$iterations
alpha_change <- .path$alpha_change
beta_change <- .path$beta_change
constraint_residual <- .path$constraint_residual
converged <- .path$converged
skipped_zero_updates <- .path$skipped_zero_updates
checked_beta_updates <- .path$checked_beta_updates
full_gradient_scans <- .path$full_gradient_scans
Y_1<-matrix(rep(Y,each=nlam),N,nlam,byrow=TRUE)
GIC<-.Call("_CDaLCqr_GIC",t(alp_0), t(bet_0), X.p,Y_1, Z.p,tau,kk,n,N,p,r,nlam)
GIC_lam<-data.frame(lambda=lambda1,GIC=GIC)
lam<-min(GIC_lam$lambda[GIC_lam$GIC==min(GIC_lam$GIC)])
index<-c(1:nlam)
num_lam<-data.frame(index=index,lambda=lambda1)
ind<-num_lam$index[num_lam$lambda==lam]
bet0<-matrix(bet_0[ind,],ncol=1)
alp0<-matrix(alp_0[ind,],ncol=1)
#################################################################################
# output
diagnostics <- data.frame(lambda=lambda1, GIC=as.numeric(GIC), iterations=iterations,
                          alpha_change=alpha_change, beta_change=beta_change,
                          constraint_residual=constraint_residual, converged=converged,
                          skipped_zero_updates=skipped_zero_updates,
                          checked_beta_updates=checked_beta_updates,
                          full_gradient_scans=full_gradient_scans)
li<-list("alp_rq"=alp0,"beta_rq"=bet0,"lambda_best"=lam,
         "lambda_GIC"=as.numeric(GIC), "lambda_grid"=lambda1,
         "path_diagnostics"=diagnostics,
         "alpha_path"=alp_0, "beta_path"=bet_0)
return(li)
}
