#' CDaLCqr
#'
#' The method is the coordinate descent algorithm for longitudinal quantile
#' regression with high-dimensional compositional covariates. And this is the
#' main function.
#'
#' @param x data for r covariates and p compositional covariates
#' @param y data for response outcomes
#' @param r dimension of covariates
#' @param p dimension of compositional covariates
#' @param n number of subjects
#' @param tau quantile
#' @param ini initialization method, either 1 (default) or 2
#' @param penalty penalty type: Adaptive Lasso (default), MCP, or SCAD
#' @param lambda sequence of tuning parameter lambda('s) or NULL
#' @param eps parameter for the determination of iteration convergence in the CDA, defaulted as 1e-06
#' @param maxit maximum number of iterations in the CDA, defaulted as 1e+04
#' @param kk parameter for the smooth approximate loss function in the CDA, defaulted as 0.01
#' @param mu penalty parameter in the CDA, defaulted as 1
#' @param eps1 used when ini=2, defaulted as 1e-03
#' @param maxit1 used when ini=2, defaulted as 1e+03
#' @param wgt_scale used to scale the whole weights, in conjunction with lambda, and defaulted as 1
#'
#' @return estimated coefficient values of covariates and compositional covariates
#' @export
#'
#' @examples CDaLCqr(X,Y,r=4,p=400,n=100,tau=0.8,ini=1,lambda=NULL,kk=0.1)
#' @examples CDaLCqr(X,Y,r=4,p=400,n=100,tau=0.5,ini=1,lambda=NULL)
#'
#'
CDaLCqr <-
function(x, y, r, p, n, tau, ini = 1, lambda, eps = 1e-06, maxit = 1e+04,
         kk = 0.01, mu=1, eps1 = 1e-03, maxit1 = 1000, wgt_scale =1, use_cpp = TRUE, penalty = c("Adaptive Lasso", "MCP", "SCAD"), a=NULL,
         select_ka = FALSE, kk_grid = NULL, a_grid = NULL){
    ############################################################################
    penalty <- normalize_penalty(penalty)
    if (penalty=="MCP") {
      if(is.null(a) && !(isTRUE(select_ka) && !is.null(a_grid))){
        stop("Parameter a or a_grid must be specified when penalty is MCP")
      } else if(!is.null(a) && a < 1){
        stop("Parameter a should be greater than 1")
      }
      if(wgt_scale!=1) warning("Parameter wgt_scale will not be used when penalty is nonconvex")
    }else if(penalty=="SCAD"){
      if(is.null(a) && !(isTRUE(select_ka) && !is.null(a_grid))){
        stop("Parameter a or a_grid must be specified when penalty is SCAD")
      } else if(!is.null(a) && a < 2){
        stop("Parameter a should be greater than 2")
      }
      if(wgt_scale!=1) warning("Parameter wgt_scale will not be used when penalty is nonconvex")
    }else{
      if(!is.null(a)) warning("Parameter a will not be used with the Adaptive Lasso penalty")
    }
    if(is.null(a)) a <- 1
    ############################################################################
    #data setup
    this.call <- match.call()
    #y <- drop(y)
    y<- as.matrix(as.double(y))
    x <- as.matrix(x)
    storage.mode(x) <- "double"
    r <- as.integer(r)
    p <- as.integer(p)
    n <- as.integer(n)
    tau <- as.double(tau)
    Nrp <- dim(x)
    N <- as.integer(Nrp[1])
    rp <- as.integer(Nrp[2])
    if (length(y) != N)
      stop("x and y have different number of observations")
    if ((r+p != rp) | r<=0 | p<=0)
      stop("the input of r or p is incorrect")
    if (n > N | n<=0)
      stop("the input of n is incorrect")
    if (tau<0 | tau>1)
      stop("tau must be between 0 and 1")
    ############################################################################
    #parameter setup
    maxit <- as.integer(maxit)
    eps <- as.double(eps)
    maxit1 <- as.integer(maxit1)
    eps1 <- as.double(eps1)
    mu <- as.double(mu)
    kk <- as.double(kk)
    wgt_scale <- as.double(wgt_scale)
    ini <- as.integer(ini)
    if (ini<=0 | ini>=3)
      stop("the input of ini is incorrect")
    ############################################################################
    #lambda setup
    if (is.null(lambda)) {
      lambda1 <- seq(from=N/1000,to=N/50,length.out=N/5)
      nlam <- length(lambda1)
    } else {
      lambda1 <- as.vector(lambda)
      nlam <- length(lambda1)
    }
    ############################################################################
    run_fit <- function(kk_value, a_value) {
      if (ini == 1L) {
        ini1fk(x, y, r, p, n, N, tau, lambda1, nlam, eps, maxit,
               mu, kk_value, wgt_scale, penalty, a_value)
      } else {
        ini2fk(x, y, r, p, n, N, tau, lambda1, nlam, eps, maxit,
               mu, kk_value, eps1, maxit1, wgt_scale, penalty, a_value)
      }
    }
    check_loss <- function(u, tau) u * (tau - (u < 0))
    if (!isTRUE(select_ka)) {
      fit <- run_fit(kk, a)
      fit$kk_best <- kk
      fit$a_best <- a
    } else {
      kk_candidates <- sort(unique(as.double(if (is.null(kk_grid)) kk else kk_grid)))
      if (!length(kk_candidates) || any(!is.finite(kk_candidates)) || any(kk_candidates <= 0))
        stop("kk_grid must contain positive finite values")
      if (penalty == "CONVEX") {
        a_candidates <- 1
      } else {
        a_candidates <- sort(unique(as.double(if (is.null(a_grid)) a else a_grid)))
        lower_a <- if (penalty == "MCP") 1 else 2
        if (!length(a_candidates) || any(!is.finite(a_candidates)) || any(a_candidates < lower_a))
          stop("a_grid contains an invalid penalty-shape value")
      }
      tuning_grid <- expand.grid(kk = kk_candidates, a = a_candidates,
                                 KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE)
      tuning_fits <- vector("list", nrow(tuning_grid))
      tuning_gic <- rep(NA_real_, nrow(tuning_grid))
      for (i in seq_len(nrow(tuning_grid))) {
        candidate_fit <- run_fit(tuning_grid$kk[[i]], tuning_grid$a[[i]])
        coef <- c(drop(candidate_fit$alp_rq), drop(candidate_fit$beta_rq))
        residual <- drop(y) - drop(x %*% coef)
        loss <- mean(check_loss(residual, tau))
        size <- sum(abs(drop(candidate_fit$beta_rq)) >= 1e-5)
        tuning_gic[[i]] <- log(max(loss, .Machine$double.xmin)) +
          (size - 1) * log(log(n)) * log(p) / n
        tuning_fits[[i]] <- candidate_fit
      }
      selected <- which.min(tuning_gic)
      fit <- tuning_fits[[selected]]
      fit$kk_best <- tuning_grid$kk[[selected]]
      fit$a_best <- tuning_grid$a[[selected]]
      fit$tuning_GIC <- cbind(tuning_grid, GIC = tuning_gic)
      fit$tuning_index <- selected
    }
    #if (is.null(lambda))  ##
      #fit$lambda <- seq(from=N/1000,to=N/50,length.out=N/5)
    fit$lambda <- lambda1
    fit$call <- this.call
    ############################################################################
    class(fit) <- c("CDaLCqrNew", class(fit))
    return(fit)
}

normalize_penalty <- function(penalty) {
    choices <- c("ADAPTIVE LASSO", "MCP", "SCAD")
    key <- toupper(penalty)
    if (identical(key, choices) || identical(key, c("CONVEX", "MCP", "SCAD"))) {
        return("CONVEX")
    }
    key <- match.arg(key, c(choices, "CONVEX"))
    if (key == "ADAPTIVE LASSO") "CONVEX" else key
}
