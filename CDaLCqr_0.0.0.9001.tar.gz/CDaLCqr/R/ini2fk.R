#' ini2fk
#'
#' use WAY2: inputting the uniformly consistent estimate, which is obtained
#' through the BC method, and lambda^{*} corresponding to the BC method into the
#' CDA to get the initial estimated value of coefficients
#'
#' @param x data for r covariates and p compositional covariates
#' @param y data for response outcomes
#' @param r dimension of covariates
#' @param p dimension of compositional covariates
#' @param n number of subjects
#' @param N total number of observations
#' @param tau quantile
#' @param lambda1 sequence of tuning parameter lambda('s)
#' @param nlam the length of lambda1
#' @param eps parameter for the determination of iteration convergence in the CDA, defaulted as 1e-06
#' @param maxit maximum number of iterations in the CDA, defaulted as 1e+04
#' @param mu penalty parameter in the CDA, defaulted as 1
#' @param kk parameter for the smooth approximate loss function in the CDA, defaulted as 0.01
#' @param eps1 used when ini=2, defaulted as 1e-03
#' @param maxit1 used when ini=2, defaulted as 1e+03
#' @param wgt_scale used to scale the whole weights, in conjunction with lambda, and defaulted as 1
#'
#' @export
#'
ini2fk <- function(x, y, r, p, n, N, tau, lambda1, nlam, eps, maxit, mu, kk,
                   eps1, maxit1, wgt_scale, penalty, a) {
penalty <- normalize_penalty(penalty)
#################################################################################
#data setup
#y <- as.numeric(y)
if (kk < 0)
  stop("k must be non-negative")
kk <- as.double(kk)
if (tau < 0 | tau > 1)
  stop("taux must be between 0 and 1")
tau <- as.double(tau)
r <- as.integer(r)
p <- as.integer(p)
n <- as.integer(n)
N <- as.integer(N)
nlam <- as.integer(nlam)
wgt_scale <- as.double(wgt_scale)
eps<-as.double(eps)
maxit <- as.integer(maxit)
eps1 <- as.double(eps1)
maxit1 <- as.integer(maxit1)
mu <- as.double(mu)
#################################################################################
library(MASS)
library(quantreg)
library(Rcpp)
XZ<-as.matrix(x)
storage.mode(XZ) <- "double"
X.p<-as.matrix(XZ[,1:r])
Z.p<-as.matrix(XZ[,(r+1):(r+p)])
Y<-as.matrix(as.double(y))
lambda1<-as.vector(as.double(lambda1))
zero<-matrix(rep(0,2*p*r),ncol=r,byrow=TRUE)
d1<-diag(1,nrow=p)
d2<- -d1
HatSigma<-sqrt(apply(Z.p^2, 2, mean))
wgt<-sqrt(tau*( 1 -tau) )*HatSigma
d1_1<-d1%*%diag(wgt)
d2_1<-d2%*%diag(wgt)
d<-rbind(d1_1,d2_1)
coupled<-cbind(zero,d)
######## Find Lambda for BC's method ########
Rlambda<-rep(0,N)
tmpZ<-sweep(Z.p, 2, 1/HatSigma, '*')
for(i in 1:N){
  U<-runif(N, 0, 1)
  tmpLamb<-rep(0,length(tau))
  for(k in 1:length(tau)){
    u<-tau[k]
    tmpLamb[k]<-max( abs((u-(U<=u))%*%tmpZ/sqrt(u*(1-u))) )
  }
  Rlambda[i]<-max(tmpLamb)
}
rlambda<-quantile(Rlambda,0.1)/2
#############################################
R1<-matrix(c(rep(0,r),rep(1,p)),ncol=r+p)
R2<-matrix(c(rep(0,r),rep(-1,p)),ncol=r+p)
R<-rbind(R1,R2)
rr<-matrix(c(0,0),ncol=1)
Y_0<-rbind(Y,matrix(rep(0,2*p),ncol=1))
uce<-rq.fit.fnc(x=rbind(XZ,rlambda*coupled), y=Y_0, R=R,r=rr,tau=tau, beta=0.98, eps=1e-04)$coef
Weight<-1/(abs(uce[(r+1):(r+p)])+1e-6)
Weight<-Weight/wgt_scale  ##
Weight<-matrix(Weight,ncol=1)
a1<-matrix(uce[1:r],ncol=1)
b1<-matrix(uce[(r+1):(r+p)],ncol=1)
# call C++ core
del<-kk
model<-.Call("_CDaLCqr_cdmm",a1,b1,X.p,Y,Z.p,Weight,del,n,N,p,r,mu,rlambda,kk,0,tau,1,eps1,maxit1,penalty,a)
a1<-matrix(model[[1]],ncol=1)
b1<-matrix(model[[2]],ncol=1)
alp_0<-matrix(,nrow=nlam,ncol=r)
bet_0<-matrix(,nrow=nlam,ncol=p)
iterations <- integer(nlam)
alpha_change <- rep(NA_real_, nlam)
beta_change <- rep(NA_real_, nlam)
constraint_residual <- rep(NA_real_, nlam)
converged <- logical(nlam)
for(i in 1:nlam){
  model<-.Call("_CDaLCqr_cdmm",a1,b1,X.p,Y,Z.p,Weight,del,n,N,p,r,mu,lambda1[i],kk,0,tau,1,eps,maxit,penalty,a)
  alp_0[i,]<-model[[1]]
  bet_0[i,]<-model[[2]]
  iterations[i] <- model$iterations
  alpha_change[i] <- model$alpha_change
  beta_change[i] <- model$beta_change
  constraint_residual[i] <- model$constraint_residual
  converged[i] <- model$converged
}
Y_1<-matrix(rep(Y,each=nlam),N,nlam,byrow=TRUE)
GIC<-.Call("_CDaLCqr_GIC",t(alp_0), t(bet_0), X.p,Y_1, Z.p,tau,kk,n,N,p,r,nlam)
GIC_lam<-data.frame(lambda=lambda1,GIC=GIC)
lam<-min(GIC_lam$lambda[GIC_lam$GIC==min(GIC_lam$GIC)])
index<-c(1:nlam)
num_lam<-data.frame(index=index,lambda=lambda1)
ind<-num_lam$index[num_lam$lambda==lam]
bet0<-matrix(bet_0[ind,],ncol=1)
alp0<-matrix(alp_0[ind,],ncol=1)
#################################################################################
# output
diagnostics <- data.frame(lambda=lambda1, GIC=as.numeric(GIC), iterations=iterations,
                          alpha_change=alpha_change, beta_change=beta_change,
                          constraint_residual=constraint_residual, converged=converged)
li<-list("alp_rq"=alp0,"beta_rq"=bet0,"lambda_best"=lam,
         "lambda_GIC"=as.numeric(GIC), "lambda_grid"=lambda1,
         "path_diagnostics"=diagnostics)
return(li)
}
